var dataArray=[];
exports.findAll = function(req, res) {

  var mysql = require('mysql');
  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  con.query('SELECT * from course', function(err, rows) {
    con.end();
      if(!err)
        res.send(rows);
      else {
        console.log('Error while performing Query.');
      }
    });

};

exports.findByStudent = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;
  con.query('SELECT courseId, courseName, courseCode FROM course NATURAL JOIN takes NATURAL JOIN student WHERE studentId=' + id,function(err,rows){
    if(!err) {
      var finalData = [];
      if (rows.length > 0) {
        var courseIds = rows.map(function(course){
          var format =
                        {
                         'courseId':'',
                         'courseName':'',
                         'courseCode':'',
                         'tutors':[]
                       };
          format.courseId = course.courseId;
          format.courseName = course.courseName;
          format.courseCode = course.courseCode;
          finalData.push(format);
          return course.courseId;
        });
        var iterations = 0;
        courseIds.map(function(id){
          con.query('SELECT tutorId, userFirstName, userLastName, userImage, userEmail FROM user NATURAL JOIN tutor NATURAL JOIN teaches NATURAL JOIN course WHERE available=1 AND courseId=' + id, function(error, rows){
            if(!error) {
              //Retrieve ids of this monster
              var ids = finalData.map(function(course){
                return course.courseId;
              })

              var idx = ids.indexOf(id);
              rows.map(function(tutor){
                finalData[idx].tutors.push(tutor);
              });
              iterations++;
              if(iterations==courseIds.length) {
                res.send(finalData);
                con.end();
              }
            }
            else{
              console.log(error);
            }
          });
        });
      }
      else {
        res.send(rows);
        con.end();
      }
    }
    else {
       console.log(err);
    }
  });
};

exports.findByTutor = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;

  con.query('SELECT * from courses natural join tutor where tutorId=' + id, function(err, result) {
    con.end();
      if(!err)
        res.send(result);
      else {
        console.log('Error while performing Query.');
      }

    });

};

exports.newCourses = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });

  var iterations = 1;

  req.body.map(function(course) {
    var sid = course.studentId;
    var cid = course.courseId;
    var done;
    con.query('INSERT INTO takes(studentId, courseId) VALUES(' + sid + ', ' + cid +')', function(err, result) {
      if(!err)
        done=result;
      else {
        console.log(err);
      }
    });
    if (iterations == req.body.length) {
      res.send(done);
      con.end();
    }
    else {
      iterations++;
    }

  });

};

exports.findOtherCourses = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;

  con.query('SELECT * from course WHERE courseId NOT IN (SELECT courseId from course natural join tutor natural join teaches where tutorId=' + id+')', function(err, result) {
    con.end();
      if(!err)
        console.log("");
      else {
        console.log(err);
      }
      res.send(result);
    });

};

exports.findOtherStudentCourses = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;

  con.query('SELECT * from course WHERE courseId NOT IN (SELECT courseId from course natural join student natural join takes where studentId=' + id+')', function(err, result) {
    con.end();
      if(!err)
        console.log("");
      else {
        console.log(err);
      }
      res.send(result);
    });

};
