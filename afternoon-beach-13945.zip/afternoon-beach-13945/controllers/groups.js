exports.findAll = function(req, res) {

  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  con.query('SELECT * from groups', function(err, rows) {
    con.end();
      if(!err)
        res.send(rows);
      else {
        console.log('Error while performing Query.');
      }
    });

};

exports.findOther = function(req, res) {

  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;

  con.query("SELECT * FROM groups NATURAL JOIN pertains NATURAL JOIN student WHERE groupSize<>groupCapacity AND groupsId NOT IN (SELECT groupsId FROM groups NATURAL JOIN pertains NATURAL JOIN student WHERE studentId="+ id + ")", function(err, rows) {
    con.end();
      if(!err)
        res.send(rows);
      else {
        console.log('Error while performing Query.');
      }
    });

};

exports.findById = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;
  console.log(id);

  con.query('SELECT groupsId, groupName, groupSize, groupCapacity, courseId FROM groups NATURAL JOIN pertains NATURAL JOIN student WHERE studentId=' + id,function(err,rows){
    if(!err) {
        var finalData = [];
        if (rows.length > 0) {
          var groupIds = rows.map(function(group){
            var format =
                          {
                            'groupId':'',
                            'groupName':'',
                            'groupSize':'',
                            'groupCapacity':'',
                            'courseId':'',
                            'members':[]
                          };
            format.groupId = group.groupsId;
            format.groupName = group.groupName;
            format.groupSize = group.groupSize;
            format.groupCapacity = group.groupCapacity;
            format.courseId = group.courseId;
            finalData.push(format);
            return group.groupsId;
          });
          var iterations = 0;
          groupIds.map(function(id){
            con.query('SELECT userFirstName, userLastName, userImage FROM user NATURAL JOIN student NATURAL JOIN pertains NATURAL JOIN groups WHERE groupsId=' + id, function(error, rows){
              if(error) {
                console.log(error);
              }

              //Retrieve ids of this monster
              var ids = finalData.map(function(group){
                return group.groupId;
              })

              var idx = ids.indexOf(id);
              rows.map(function(student){
                finalData[idx].members.push(student);
              });
              iterations++;
              if(iterations==groupIds.length) {
                res.send(finalData);
                con.end();
              }
            });
          });
        }
        else {
          res.send(rows);
          con.end();
        }
      }
      else {
        console.log(err);
      }
  });
};

exports.findGroupStudents = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;

  con.query('SELECT * from groups natural join students where groupId=' + id, function(err, result) {
    con.end();
      if(!err)
        res.send(result);
      else {
        console.log('Error while performing Query.');
      }
    });

};

exports.findMessages = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;

  con.query('SELECT userId FROM user NATURAL JOIN student WHERE studentId='+id, function(err,rows){
    if(!err){
      if(rows.length>0){
          var receiverId = rows[0].userId;
          con.query('SELECT groupName, groups.groupsId, userFirstName, userLastName, userImage, body, groupmessages.senderId FROM groups, groupMessages NATURAL JOIN pertains NATURAL JOIN user NATURAL JOIN student WHERE groups.groupsid = groupmessages.groupsId AND groupmessages.senderId <> '+receiverId+' AND studentId=' + id, function(err, messages) {
              if(!err && messages.length>0){
                var senderId = messages[0].senderId;
                con.query('SELECT userFirstName, userLastName, userImage FROM user WHERE userId='+senderId,function(err,rows){
                  if(!err){
                    var name = rows[0].userFirstName;
                    var lastname = rows[0].userLastName;
                    var image = rows[0].userImage;
                    var finalResult = messages.map(function(row){
                      row.userFirstName = name;
                      row.userLastName = lastname;
                      row.userImage = image;
                      return row;
                    });
                    res.send(finalResult);
                  }
                  else{
                    console.log(err);
                  }
                });
              }
              else if(err) {
                console.log(err);
              }
              else{
                res.send(messages);
              }
            });
      }
      else{
        res.send(rows);
      }

    }
    else{
      console.log(err);
    }
  })

};

exports.sendMessage = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });

  //senderId pk, body, date, time, groupsId
  var senderId = req.body.senderId;
  var body = req.body.message;
  var date = Date.now().toString();
  var groupsId = req.body.groupsId;

  var name = "";
  con.query("SELECT userFirstName FROM user WHERE userId ="+senderId,function(err,rows){
    if(!err)
      name = rows[0].userFirstName;
  });


  con.query("INSERT INTO groupMessages (senderId, body, date, groupsId) "+
  "VALUES("+senderId+",'"+body+"','"+date+"',"+groupsId+")",function(err,rows){
    if(!err){
      con.query("SELECT userToken, userFirstName, groupName FROM groups NATURAL JOIN pertains NATURAL JOIN "
      +"student NATURAL JOIN user WHERE userId <> "+senderId+" AND groupsId ="+groupsId,function(err,rows){
        if(!err){
          //send push notification
          var FCM = require('fcm-push');
          var serverkey = 'AIzaSyB7rLxsu4wJ4reA7rJYBn7DWQHd3fPNKq4';
          var fcm = new FCM(serverkey);
          for(var i = 0; i<rows.length; i++){
            var pushToken = rows[i].userToken;
            var groupName = rows[i].groupName;
            var userName = rows[i].userFirstName;
            var message =  {
                  to : pushToken,
                  data : {
                    'title' : 'Title',
                    'body' : 'Body'
                  },
                  notification : {
                    title : "Hi "+userName,
                    body : name+" wrote something at "+groupName,
                    color: "blue",
                    sound : true,
                    icon: 'myicon'
                  }
            };

            fcm.send(message, function(err,response){
              if(err) {
                console.log("Something has gone wrong !");
              } else {
                console.log("Successfully sent with response :",response);
              }
            });
          }
          res.send(rows)
        }
        else{
          console.log(err)
        }
      });
    }
    else{
      console.log(err);
    }
  })


  // con.query('SELECT * from user where userId=' + id, function(err, result) {
  //   con.end();
  //     if(!err)
  //       console.log("");
  //     else {
  //       console.log('Error while performing Query.');
  //     }
  //     res.send(result);
  //   });
};

exports.leave = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });

  var sid = req.body.studentId;
  var gid = req.body.groupsId;

  var name = "";
  con.query("SELECT userFirstName FROM student NATURAL JOIN user WHERE studentId ="+sid,function(err,rows){
     if(!err)
       name = rows[0].userFirstName;
  });

  con.query('DELETE FROM pertains WHERE studentId=' + sid + ' AND groupsId=' + gid, function(err, result) {
    if(!err) {
      console.log(result);
      con.query('UPDATE groups SET groupSize = groupSize-1 WHERE groupsId=' + gid, function(err, result) {
        if (!err) {
          console.log(result);
          con.query('SELECT groupSize FROM groups WHERE groupsId=' + gid, function(err, result) {
            if (!err) {
              console.log(result);
              var size = result.map(function(group) {
                return group.groupSize;
              })
              if (size[0] == 0) {
                con.query('DELETE FROM groups WHERE groupsId=' + gid, function(err, result) {
                  con.end();
                  if (!err) {
                    console.log(result);
                  }
                  else {
                    console.log(err);
                  }
                });
              }
              else {
                con.query("SELECT userToken,groupName,userFirstName FROM groups NATURAL JOIN pertains NATURAL JOIN "
                +"student NATURAL JOIN user WHERE studentId <> "+sid+" AND groupsId ="+gid,function(err,rows){
                  if(!err){
                    //send push notification
                    var FCM = require('fcm-push');
                    var serverkey = 'AIzaSyB7rLxsu4wJ4reA7rJYBn7DWQHd3fPNKq4';
                    var fcm = new FCM(serverkey);
                    for(var i = 0; i<rows.length; i++){
                      var pushToken = rows[i].userToken;
                      var groupName = rows[i].groupName;
                      var userName = rows[i].userFirstName;
                      var message =  {
                            to : pushToken,
                            data : {
                              'title' : 'Title',
                              'body' : 'Body'
                            },
                            notification : {
                              title : "Hi "+userName,
                              body : name+" has left "+groupName,
                              color: "blue",
                              sound : true,
                              icon: 'myicon'
                            }
                      };

                      fcm.send(message, function(err,response){
                        if(err) {
                          console.log("Something has gone wrong !");
                        } else {
                          console.log("Successfully sent with resposne :",response);
                        }
                      });
                    }

                  }
                  else{
                    console.log(err)
                  }
                });
              }
            }
            else {
              console.log(err);
            }
          });
        }
        else
          console.log(err);
      });
    }
    else {
      console.log(err);
    }
    res.send(result);
  });
};

exports.createGroup = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });

  var cid = req.body.courseId;
  var gname = req.body.groupName;
  var gcapacity = req.body.groupCapacity;
  var sid = req.body.studentId;

  con.query('INSERT INTO groups(courseId, groupName, groupSize, groupCapacity) VALUES(' + cid + ', ' + gname + ', 1, ' + gcapacity + ')', function(err, result) {
    if(!err) {
      console.log("");
      con.query('SELECT groupsId FROM groups WHERE courseId=' + cid + ' AND groupName=' + gname + ' AND groupSize=1 AND groupCapacity=' + gcapacity, function(err, result){
        if (!err) {
          var id = result.map(function(group) {
            return group.groupsId;
          });
          console.log(id[0]);
          var gid = id[0];

          con.query('INSERT INTO pertains(studentId, groupsId) VALUES(' + sid + ', ' + gid + ')', function(err, result) {
            con.end();
            if(!err)
              console.log("");
            else {
              console.log(err);
            }
          })
        }
        else {
          console.log(err);
        }
      });
    }
    else {
      console.log(err);
    }
    res.send(result);
  });
};

exports.joinGroup = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });

  // console.log(JSON.stringify(req.body));

  var iterations = 0;

  var sid = req.body.studentId;

  req.body.groups.map(function(group) {
    var gid = group.id;
    var name = "";

    con.query("SELECT userFirstName FROM student NATURAL JOIN user WHERE studentId ="+sid,function(err,rows){
       if(!err) {
          name = rows[0].userFirstName;

          con.query('INSERT INTO pertains(studentId, groupsId) VALUES(' + sid + ', ' + gid + ')', function(err, result) {
            if(!err) {
              console.log("insert: " + result);
              con.query('UPDATE groups SET groupSize = groupSize + 1 WHERE groupsId=' + gid, function(err, result) {
                if (!err){
                  console.log("update: " + result);
                  con.query("SELECT userToken,groupName,userFirstName FROM groups NATURAL JOIN pertains NATURAL JOIN "
                  +"student NATURAL JOIN user WHERE studentId <> "+sid+" AND groupsId ="+gid,function(err,rows){
                    if(!err){
                      //send push notification
                      var FCM = require('fcm-push');
                      var serverkey = 'AIzaSyB7rLxsu4wJ4reA7rJYBn7DWQHd3fPNKq4';
                      var fcm = new FCM(serverkey);
                      for(var i = 0; i<rows.length; i++){
                        var pushToken = rows[i].userToken;
                        var groupName = rows[i].groupName;
                        var userName = rows[i].userFirstName;
                        var message =  {
                              to : pushToken,
                              data : {
                                'title' : 'Title',
                                'body' : 'Body'
                              },
                              notification : {
                                title : "Hi "+userName,
                                body : name+" has join "+groupName,
                                color: "blue",
                                sound : true,
                                icon: 'myicon'
                              }
                        };

                        fcm.send(message, function(err,response){
                          if(err) {
                            console.log("Something has gone wrong !");
                          } else {
                            console.log("Successfully sent with resposne :",response);
                          }
                        });
                      }

                    }
                    else{
                      console.log(err)
                    }
                  });
                }
                else {
                  console.log(err);
                }
              })
            }
            else {
              console.log(err);
            }
          });
        }
      });
    console.log(iterations);
    if(iterations == (req.body.groups.length - 1)) {
      console.log('in');
      res.sendStatus(200);
      //con.end();
    }
    else
      iterations++;
  });

};
