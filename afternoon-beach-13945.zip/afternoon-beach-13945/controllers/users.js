exports.findAll = function(req, res) {

  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  con.query('SELECT * from user', function(err, rows) {
    con.end();
      if(!err)
        console.log("");
      else {
        console.log('Error while performing Query.');
      }
      res.send(rows);
    });

};

exports.findById = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;

  con.query('SELECT * from user where userId=' + id, function(err, result) {
    con.end();
      if(!err)
        console.log("");
      else {
        console.log('Error while performing Query.');
      }
      res.send(result);
    });

};

exports.newUser = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  //Attributes
  var userFirstName = req.body.userFirstName;
  var userLastName = req.body.userLastName;
  //var userImage = req.body.userImage;
  var userEmail = req.body.userEmail;
  var userPassword = req.body.userPassword;
  var isTutor = req.body.isTutor;
  var userStatus = req.body.userStatus;
  var userImage = "https://s-media-cache-ak0.pinimg.com/236x/8d/25/a1/8d25a16b40432072ddf528b41d445f37.jpg";

  con.query("INSERT INTO user (userFirstName, userLastName, userImage, userEmail,"
  +"userPassword,isTutor,userStatus) VALUES('" + userFirstName + "','" +  userLastName + "', '"
  + userImage + "', '" + userEmail + "', '"+ userPassword + "','" + isTutor + "','" + userStatus + "')", function(err, result) {
      if(!err) {
        console.log("Creado");
        con.query("SELECT userId FROM user WHERE userEmail='" + userEmail + "'", function(err, result) {
          if (!err) {
            var id = result[0].userId;

            console.log("Creando un: " + isTutor);

            if (isTutor == 0) {
              con.query("INSERT INTO student(userId) VALUES(" + id + ")", function(err, result) {
                // con.end();
                  if (!err) {
                    console.log("insert into student: " + result);
                    con.query("SELECT studentId FROM student WHERE userId=" + id, function(err, result) {
                      if (!err) {
                        console.log("select studentId: " + result);
                        var sid = result[0].studentId;
                        con.query("INSERT INTO countdown(studentId) VALUES(" + sid + ")", function(err, result) {
                          con.end();
                          if (!err) {
                            console.log("insert into countdown: " + result);
                            res.send(result);
                          }
                          else {
                            console.log(err);
                          }
                        })
                      }
                      else {
                        console.log(err)
                      }
                    })
                    // res.send(result);
                  }
                  else {
                    console.log(err);
                  }
              });
            }
            else if (isTutor == 1) {
              con.query("INSERT INTO tutor(userId) VALUES(" + id + ")", function(err, result) {
                con.end();
                  if (!err) {
                    res.send(result);
                  }
                  else {
                    console.log(err);
                  }
              });
            }
          }
          else {
            console.log(err);
          }
        });
      }
      else {
        console.log(err);
      }
    });
};

exports.reply = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });

  console.log(req.body);
  res.send(req.body);

  con.end();

  // con.query('SELECT * from user where userId=' + id, function(err, result) {
  //   con.end();
  //     if(!err)
  //       console.log("");
  //     else {
  //       console.log('Error while performing Query.');
  //     }
  //     res.send(result);
  //   });
};

exports.getId = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });

  var email = req.body.email;
  // console.log(req.body);
  // res.send(req.body);

  console.log("Este es mi email!!!" + email);

  con.query("SELECT userId, isTutor FROM user WHERE userEmail='" + email +"'", function(err, result) {
    // con.end();
    if(!err) {
      console.log('result:'+JSON.stringify(result));
      // res.send(result);
      result.map(function(user) {
        var userId = user.userId;
        var isTutor = user.isTutor;
      //
        if (isTutor === 0) {
          con.query('SELECT studentId,userId,isTutor FROM user NATURAL JOIN student WHERE userId=' + userId, function(err, result) {
            con.end();
            if(!err) {
              //console.log("");
              res.send(result);
            }
            else {
              console.log(err);
            }
          });
        }
        else{
          con.query('SELECT tutorId,userId,isTutor FROM user NATURAL JOIN tutor WHERE userId=' + userId, function(err, result) {
            con.end();
            if(!err) {
              console.log("");
              res.send(result);
            }
            else
              console.log(err);
          });
        }
    })
  }
    else {
      console.log(err);
    }
  });
};

exports.updateSettings = function(req, res) {

  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var userId = req.body.userId;
  var status = req.body.userStatus;
  var image = req.body.userImage;

  con.query("UPDATE user SET userImage='" + image + "', userStatus='" + status + "' WHERE userId=" + userId, function(err, result) {
    con.end();
      if(!err) {
        console.log(result);
      }
      else {
        console.log(err);
      }
      res.send(result);
    });

};

exports.updateToken = function(req, res) {

  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var userId = req.body.userId;
  var token = req.body.userToken;

  con.query("UPDATE user SET userToken='" + token + "'WHERE userId=" + userId, function(err, result) {
    con.end();
      if(!err) {
        console.log(result);
      }
      else {
        console.log(err);
      }
      res.send(result);
    });

};

exports.deleteUser = function(req, res) {

  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var userId = req.body.userId;
  var isTutor = req.body.isTutor;
  var otherId;

  if(isTutor === 1)
  {
    con.query("START TRANSACTION",function(err,rows){
      if(!err){
        con.query("SELECT tutorId FROM tutor WHERE userId = "+userId, function(err, result) {
            if(!err){
                otherId = result[0].tutorId;

                con.query("DELETE FROM user WHERE userId = "+userId, function(err, result) {

                       if(err){
                            console.log(err);
                            con.query("ROLLBACK");
                            con.end();
                       }
                       else{
                            con.query("DELETE FROM tutor WHERE tutorId = "+otherId, function(err, result){

                                               if(err){
                                                    console.log(err);
                                                    con.query("ROLLBACK");
                                                    con.end();
                                               }
                                               else{
                                                    con.query("DELETE FROM message WHERE tutorId ="+otherId, function(err, result) {
                                                                        if(err){
                                                                             console.log(err);
                                                                             con.query("ROLLBACK");
                                                                             con.end();
                                                                        }
                                                                        else{
                                                                            con.query("COMMIT");
                                                                            con.end();
                                                                            res.send(result);
                                                                        }
                                                                })
                                               }
                                        });
                       }

                });
            }
            else
            {
                console.log(err);
                con.query("ROLLBACK");
                con.end();
            }

        })
      }
    });

  }

  else
  {
     con.query("START TRANSACTION",function(err,rows){
       if(!err){
         con.query("SELECT studentId FROM student WHERE userId = "+userId, function(err, result) {
                if(!err){
                    otherId = result[0].studentId;

                    con.query("DELETE FROM user WHERE userId = "+userId, function(err, result) {

                        if(err){
                            console.log(err);
                            con.query("ROLLBACK");
                            con.end();
                        }
                        else{
                            con.query("DELETE FROM student WHERE studentId ="+otherId, function(err, result){

                                                    if(err){
                                                        console.log(err);
                                                        con.query("ROLLBACK");
                                                        con.end();
                                                    }
                                                    else{
                                                        con.query("DELETE FROM countdown WHERE studentId = "+otherId, function(err, result){

                                                                                if(err)
                                                                                {
                                                                                    console.log(err);
                                                                                    con.query("ROLLBACK");
                                                                                    con.end();
                                                                                }
                                                                                else{
                                                                                    con.query("DELETE FROM message WHERE studentId = "+otherId, function(err,result){

                                                                                                            if(err)
                                                                                                            {
                                                                                                                console.log(err);
                                                                                                                con.query("ROLLBACK");
                                                                                                                con.end();
                                                                                                            }
                                                                                                            else{
                                                                                                                con.query("DELETE FROM groupMessages where senderId = "+otherId, function(err, result){

                                                                                                                                        if(err)
                                                                                                                                        {
                                                                                                                                            console.log(err);
                                                                                                                                            con.query("ROLLBACK");
                                                                                                                                            con.end();
                                                                                                                                        }
                                                                                                                                        else{
                                                                                                                                          //
                                                                                                                                              con.query("SELECT groupsId FROM groups NATURAL JOIN pertains WHERE studentId="+otherId,function(err,myGroups){
                                                                                                                                                if(!err){
                                                                                                                                                    myGroups.map(function(group){
                                                                                                                                                        con.query("UPDATE groups SET groupSize = groupSize - 1 WHERE groupsId ="+group.groupsId,function(err){
                                                                                                                                                            if(err){
                                                                                                                                                                console.log(err);
                                                                                                                                                                con.query("ROLLBACK");
                                                                                                                                                            }
                                                                                                                                                        })
                                                                                                                                                    });
                                                                                                                                                }
                                                                                                                                              })
                                                                                                                                          //
                                                                                                                                            con.query("SELECT * FROM user", function(err, result)
                                                                                                                                                            {
                                                                                                                                                                 if(!err)
                                                                                                                                                                 {
                                                                                                                                                                    con.query("DELETE FROM pertains WHERE studentId = "+otherId,function(err,result){

                                                                                                                                                                           if(err)
                                                                                                                                                                           {
                                                                                                                                                                                console.log(err);
                                                                                                                                                                                con.query("ROLLBACK");
                                                                                                                                                                                con.end();
                                                                                                                                                                           }
                                                                                                                                                                           else{
                                                                                                                                                                                con.query("DELETE FROM groups WHERE groupSize = 0", function(err, result){


                                                                                                                                                                                                              if(err)
                                                                                                                                                                                                              {
                                                                                                                                                                                                                    console.log(err);
                                                                                                                                                                                                                    con.query("ROLLBACK");
                                                                                                                                                                                                                    con.end();
                                                                                                                                                                                                              }
                                                                                                                                                                                                              else
                                                                                                                                                                                                              {
                                                                                                                                                                                                                    con.query("COMMIT");
                                                                                                                                                                                                                    con.end();
                                                                                                                                                                                                              }
                                                                                                                                                                                                        });
                                                                                                                                                                           }

                                                                                                                                                                    });


                                                                                                                                                                 }
                                                                                                                                                                 else
                                                                                                                                                                 {
                                                                                                                                                                    console.log(err);
                                                                                                                                                                    con.query("ROLLBACK");
                                                                                                                                                                    con.end();
                                                                                                                                                                 }

                                                                                                                                                            });
                                                                                                                                        }
                                                                                                                                });
                                                                                                            }

                                                                                                    });
                                                                                }

                                                                        });
                                                    }

                                            });
                        }

                    });












                    res.send(result);
                }
                else
                {
                    console.log(err);
                    con.query("ROLLBACK");
                    con.end();
                }
            })
       }
     })


  }

}
