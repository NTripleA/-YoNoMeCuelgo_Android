exports.findAll = function(req, res) {

  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  con.query('SELECT * from student', function(err, rows) {
    con.end();
      if(!err)
        console.log("");
      else {
        console.log('Error while performing Query.');
      }
      res.send(rows);
    });

};

exports.findMessages = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;
  var userId;
  con.query('SELECT userId FROM student NATURAL JOIN user WHERE studentId = '+id, function(err, rows){
    if(!err){
      userId = rows[0].userId;
      con.query('SELECT userFirstName, userLastName, userImage, title, body, tutorId FROM message NATURAL JOIN tutor NATURAL JOIN user WHERE receiverId = '+userId+' AND studentId=' + id, function(err, result) {
        con.end();
          if(!err)
            console.log("");
          else {
            console.log(err);
          }
          res.send(result);
        });
    }
    else{
      console.log(err);
    }
  })

};

exports.findCountdown = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log(err);
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;
  console.log(id);

  // con.query('SELECT title, time from countdown NATURAL JOIN student where studentId=' + id, function(err, result) {
  con.query('SELECT title, time FROM countdown WHERE studentId=' + id, function(err, result) {
    con.end();
      if(!err)
        res.send(result);
      else {
        console.log(err);
      }
    });
};

exports.findInfoById = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log(err);
      return;
    }
    console.log('Connection established');
  });

  var id = req.params.id;
  console.log(id);

  con.query('SELECT * FROM user NATURAL JOIN student WHERE userId=' + id, function(err, result) {
    con.end();
      if(!err) {
        console.log("Resultado de query: " + result);
        res.send(result);
      }
      else {
        console.log(err);
      }
    });
};

exports.newCountdown = function(req, res) {
  var mysql = require('mysql');

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });

  var studentId = req.body.studentId;
  var date = req.body.newTime;
  var newTitle = req.body.newTitle;

  // var query = "UPDATE countdown SET time='" + date + "', title='" + newTitle + "' WHERE studentId=" + studentId;
  // console.log("query: "+query);

  con.query("UPDATE countdown SET time='" + date + "', title='" + newTitle + "' WHERE studentId=" + studentId, function(err, result) {
    con.end();
      console.log("Salio esto: "+JSON.stringify(req.body));
      if(!err)
        res.send(result);
      else {
        console.log(err);
      }
    });
};

exports.sendMessage = function(req, res) {
  var mysql = require('mysql');
  var FCM = require('fcm-push');
  var serverkey = 'AIzaSyB7rLxsu4wJ4reA7rJYBn7DWQHd3fPNKq4';
  var fcm = new FCM(serverkey);

  // First you need to create a connection to the db
  var con = mysql.createConnection({
    host: "mysql4.gear.host",
    user: "icom5016",
    password: "Yk8Hp?sFX0-V",
    database: "icom5016"
  });

  con.connect(function(err){
    if(err){
      console.log('Error connecting to Db');
      return;
    }
    console.log('Connection established');

  });
  var studentId = req.body.studentId;
  var tutorId = req.body.tutorId;
  var senderId = req.body.userId;
  var title = "Hey there!"
  var body = req.body.message;
  var date = Date.now().toString();
  var receiverId;
  var pushFirstName;
  var pushToken;
  console.log('sender id '+senderId);

  con.query('SELECT userFirstName, isTutor FROM user where userId=' + senderId,function(err,result){
    if(!err){
      console.log('1');
      pushFirstName = result[0].userFirstName;
      var isTutor = result[0].isTutor;
      console.log('isTutor '+isTutor);
      if(isTutor==1){
        receiverId = studentId;

        con.query('SELECT userToken, userId FROM user NATURAL JOIN student where studentId=' + receiverId, function(err, result) {
            if(!err){
              console.log('2');
              receiverId = result[0].userId;
              pushToken = result[0].userToken;
              con.query("INSERT INTO message(title,body,date,receiverId,studentId,tutorId) "
              +"VALUES('"+title+"',"+body+",'"+date+"',"+parseInt(receiverId)+","+parseInt(studentId)+","+parseInt(tutorId)+")", function(err, result) {
                con.end();
                if(!err){
                  var message =  {
                        to : pushToken,
                        data : {
                          'title' : 'Title',
                          'body' : 'Body'
                        },
                        notification : {
                          title : 'New message from '+pushFirstName,
                          body : body,
                          color: "blue",
                          sound : true,
                          icon: 'myicon'
                        }
                  };

                  fcm.send(message, function(err,response){
                    if(err) {
                      console.log("Something has gone wrong !");
                    } else {
                      console.log("Successfully sent with resposne :",response);
                    }
                  });
                }
                else{
                  console.log(err);
                }
              })
            }
            else {
              console.log(err);
            }
          });

      }
      else{
        receiverId = tutorId;

        con.query('SELECT userToken, userId FROM user NATURAL JOIN tutor where tutorId=' + receiverId, function(err, result) {
            if(!err){
              console.log('3');
              receiverId = result[0].userId;
              pushToken = result[0].userToken;
              con.query("INSERT INTO message(title,body,date,receiverId,studentId,tutorId) "
              +"VALUES('"+title+"',"+body+",'"+date+"',"+parseInt(receiverId)+","+parseInt(studentId)+","+parseInt(tutorId)+")", function(err, result) {
                con.end();
                if(!err){
                  var message =  {
                        to : pushToken,
                        data : {
                          'title' : 'Title',
                          'body' : 'Body'
                        },
                        notification : {
                          title : 'New message from '+pushFirstName,
                          body : body,
                          color: "blue",
                          sound : true,
                          icon: 'myicon'
                        }
                  };

                  fcm.send(message, function(err,response){
                    if(err) {
                      console.log("Something has gone wrong !");
                    } else {
                      console.log("Successfully sent with resposne :",response);
                    }
                  });
                }
                else{
                  console.log(err);
                }
              })
            }
            else {
              console.log(err);
            }
          });
      }

    }
    else{
      console.log(err);
    }
  });
};
